import { Store } from "./data.js";

const ADMIN_EMAIL = "admin@cuban-fashioner.com";
const ADMIN_PASSWORD = "Cuba2026!";
const FALLBACK_IMAGE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 300'%3E%3Crect width='400' height='300' fill='%23f1f5f1'/%3E%3Crect x='130' y='80' width='140' height='140' rx='18' fill='%23d9e9db'/%3E%3Cpath d='M205 101l-30 52h23l-5 45 37-59h-25z' fill='%234e9961'/%3E%3Ctext x='200' y='253' text-anchor='middle' font-family='Arial' font-size='14' fill='%237b887e'%3EBater%C3%ADa para laptop%3C/text%3E%3C/svg%3E";

const $ = selector => document.querySelector(selector);
const productGrid = $("#product-grid");
const modalBackdrop = $("#modal-backdrop");
const brandModal = $("#brand-modal");
const productModal = $("#product-modal");
const authModal = $("#auth-modal");
const orderModal = $("#order-modal");
const cartDrawer = $("#cart-drawer");
const toast = $("#toast");

let products = Store.getProducts();
let cart = Store.getCart();
let customer = Store.getCustomer();
let activeModal = null;
let activeBrandKey = null;
let overlayHistoryActive = false;
let toastTimeout;

function applyTheme(theme) {
  const dark = theme === "dark";
  document.body.classList.toggle("dark-mode", dark);
  document.querySelectorAll("[data-theme-toggle]").forEach(button => {
    button.setAttribute("aria-pressed", String(dark));
    button.setAttribute("aria-label", dark ? "Activar modo claro" : "Activar modo oscuro");
    button.title = dark ? "Cambiar a modo claro" : "Cambiar a modo oscuro";
    const icon = button.querySelector(".theme-icon");
    const label = button.querySelector(".theme-label");
    if (icon) icon.textContent = dark ? "☀" : "☾";
    if (label) label.textContent = dark ? "Modo claro" : "Modo oscuro";
  });
}

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function safeImage(url) {
  try {
    const parsed = new URL(url, window.location.href);
    return ["http:", "https:", "data:"].includes(parsed.protocol) ? parsed.href : FALLBACK_IMAGE;
  } catch {
    return FALLBACK_IMAGE;
  }
}

function formatPrice(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value) || 0);
}

function createPasswordSalt() {
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  return Array.from(salt, byte => byte.toString(16).padStart(2, "0")).join("");
}

async function hashPassword(password, salt) {
  const key = await window.crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await window.crypto.subtle.deriveBits({
    name: "PBKDF2",
    salt: new TextEncoder().encode(salt),
    iterations: 100000,
    hash: "SHA-256"
  }, key, 256);
  return Array.from(new Uint8Array(bits), byte => byte.toString(16).padStart(2, "0")).join("");
}

function persistProducts() {
  Store.saveProducts(products);
}

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 2600);
}

function setPageMode(admin) {
  document.body.classList.toggle("admin-mode", admin);
  document.querySelector("body > .announcement").classList.toggle("hidden", admin);
  document.querySelector("body > .site-header").classList.toggle("hidden", admin);
  document.querySelector("body > main:not(.admin-page)").classList.toggle("hidden", admin);
  document.querySelector("body > .site-footer").classList.toggle("hidden", admin);
  $("#admin-page").classList.toggle("hidden", !admin);
  if (admin) renderAdmin();
  else renderProducts();
}

function trackOverlayInHistory(element) {
  const nestedBrandModel = overlayHistoryActive && activeModal === brandModal && element !== brandModal;
  const state = {
    ...window.history.state,
    cubanFashionerOverlay: true,
    cubanFashionerBrandKey: element === brandModal ? activeBrandKey : nestedBrandModel ? activeBrandKey : null
  };
  if (nestedBrandModel) window.history.pushState(state, "", window.location.href);
  else if (overlayHistoryActive) window.history.replaceState(state, "", window.location.href);
  else {
    window.history.pushState(state, "", window.location.href);
    overlayHistoryActive = true;
  }
}

function releaseOverlayHistory() {
  if (!overlayHistoryActive) return;
  overlayHistoryActive = false;
  window.history.back();
}

function renderProducts() {
  const query = $("#search-input").value.trim().toLowerCase();
  const availability = $("#availability-filter").value;
  const visible = products.filter(product => {
    const matchesQuery = `${product.name} ${product.brand} ${product.specs}`.toLowerCase().includes(query);
    const matchesAvailability = availability === "all" || (availability === "available" ? product.stock : !product.stock);
    return matchesQuery && matchesAvailability;
  });
  $("#result-count").textContent = `${visible.length} ${visible.length === 1 ? "producto" : "productos"}`;
  $("#empty-state").classList.toggle("hidden", visible.length > 0);
  $("#brand-list-heading").classList.toggle("hidden", visible.length === 0);
  productGrid.classList.toggle("hidden", visible.length === 0);
  const brandGroups = new Map();
  visible.forEach(product => {
    const key = product.brand.trim().toLocaleLowerCase();
    if (!brandGroups.has(key)) brandGroups.set(key, []);
    brandGroups.get(key).push(product);
  });
  productGrid.innerHTML = [...brandGroups.entries()]
    .sort((left, right) => left[1][0].brand.localeCompare(right[1][0].brand, "es"))
    .map(([brandKey, group]) => `
      <button class="brand-card" data-brand="${escapeHTML(brandKey)}" type="button" aria-label="Ver modelos de ${escapeHTML(group[0].brand)}">
        <span class="brand-card-logo"><img src="assets/cuban-fashioner-logo.png" alt=""></span>
        <span class="brand-card-copy"><strong>${escapeHTML(group[0].brand)}</strong><small>${group.length} ${group.length === 1 ? "modelo" : "modelos"} de batería</small></span>
        <span class="brand-card-arrow" aria-hidden="true">↗</span>
      </button>`).join("");
  if (customer?.role !== "admin") {
    $("#account-label").textContent = customer?.name ? customer.name.split(" ")[0] : "Iniciar sesión";
  }
  updateCartBadge();
}

function renderProductCards(items) {
  return items.map(product => `
    <button class="product-card ${product.stock ? "" : "sold-out-card"}" data-product-id="${escapeHTML(product.id)}" type="button" aria-label="Ver detalles de ${escapeHTML(product.name)}">
      <span class="product-image-wrap">
        <img class="product-image" src="${escapeHTML(safeImage(product.image))}" alt="" loading="lazy">
        <span class="stock-pill ${product.stock ? "" : "sold-out"}">${product.stock ? "En stock" : "Agotado"}</span>
      </span>
      <span class="product-info">
        <span class="product-brand">${escapeHTML(product.brand)}</span>
        <span class="product-card-name">${escapeHTML(product.name)}</span>
        <span class="product-price-row"><span class="product-price">${formatPrice(product.price)} <small>USD</small></span><span class="card-arrow">↗</span></span>
      </span>
    </button>`).join("");
}

function showBrandModels(brandKey) {
  const query = $("#search-input").value.trim().toLowerCase();
  const availability = $("#availability-filter").value;
  const models = products.filter(product => {
    const matchesBrand = product.brand.trim().toLocaleLowerCase() === brandKey;
    const matchesQuery = `${product.name} ${product.brand} ${product.specs}`.toLowerCase().includes(query);
    const matchesAvailability = availability === "all" || (availability === "available" ? product.stock : !product.stock);
    return matchesBrand && matchesQuery && matchesAvailability;
  });
  if (!models.length) return;
  activeBrandKey = brandKey;
  brandModal.innerHTML = `
    <button class="modal-close" data-close type="button" aria-label="Cerrar">×</button>
    <div class="modal-identity"><img src="assets/cuban-fashioner-logo.png" alt=""><span>Cuban Fashioner</span></div>
    <div class="eyebrow"><span class="eyebrow-line"></span> MODELOS DISPONIBLES</div>
    <h2 class="brand-modal-title" id="brand-modal-title">${escapeHTML(models[0].brand)}</h2>
    <p class="brand-modal-copy">Selecciona un modelo para ver sus especificaciones, precio y disponibilidad.</p>
    <div class="brand-model-grid">${renderProductCards(models)}</div>`;
  brandModal.querySelectorAll(".product-card img").forEach(image => image.addEventListener("error", () => {
    image.src = FALLBACK_IMAGE;
    image.classList.add("fallback-image");
  }, { once: true }));
  openDialog(brandModal);
}

function openDialog(element) {
  closeDrawer(false, true);
  if (activeModal && activeModal !== element) activeModal.classList.add("hidden");
  trackOverlayInHistory(element);
  activeModal = element;
  modalBackdrop.classList.remove("hidden");
  element.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  const focusable = element.querySelector("button, input, textarea, select");
  focusable?.focus();
}

function closeModal(preserveHistory = false) {
  [brandModal, productModal, authModal, orderModal].forEach(modal => modal.classList.add("hidden"));
  activeModal = null;
  activeBrandKey = null;
  if (cartDrawer.classList.contains("hidden")) {
    modalBackdrop.classList.add("hidden");
    document.body.style.overflow = "";
  }
  if (!preserveHistory) releaseOverlayHistory();
}

function showProduct(productId) {
  const product = products.find(item => item.id === productId);
  if (!product) return;
  productModal.innerHTML = `
    <div class="product-modal-layout">
      <div class="product-modal-image"><img src="${escapeHTML(safeImage(product.image))}" alt="${escapeHTML(product.name)}"><span class="stock-pill ${product.stock ? "" : "sold-out"}">${product.stock ? "En stock" : "Agotado"}</span></div>
      <div class="modal-details">
        <button class="modal-close" data-close type="button" aria-label="Cerrar">×</button>
        <div class="modal-identity"><img src="assets/cuban-fashioner-logo.png" alt=""><span>Cuban Fashioner</span></div>
        <div class="modal-brand">${escapeHTML(product.brand)} · BATERÍA PARA LAPTOP</div>
        <h2 id="product-modal-title">${escapeHTML(product.name)}</h2>
        <p class="modal-description">Energía confiable para que tu equipo siga el ritmo de tu día.</p>
        <div class="compatibility"><strong>Especificaciones y compatibilidad</strong><p>${escapeHTML(product.specs)}</p></div>
        <div class="modal-price">${formatPrice(product.price)} <small>USD</small></div>
        <button class="button button-primary modal-add" data-add="${escapeHTML(product.id)}" type="button" ${product.stock ? "" : "disabled"}>${product.stock ? "Agregar al carrito" : "Producto agotado"} <span>＋</span></button>
      </div>
    </div>`;
  productModal.querySelector("img").addEventListener("error", event => { event.currentTarget.src = FALLBACK_IMAGE; });
  openDialog(productModal);
}

function updateCartBadge() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  $("#cart-count").textContent = String(count);
  $("#drawer-count").textContent = count ? `(${count})` : "";
}

function renderCart() {
  const normalizedCart = cart.filter(item => products.some(product => product.id === item.id && product.stock));
  if (normalizedCart.length !== cart.length) {
    cart = normalizedCart;
    Store.saveCart(cart);
  }
  const items = cart.map(item => {
    const product = products.find(entry => entry.id === item.id);
    if (!product) return "";
    return `<article class="cart-item">
      <img src="${escapeHTML(safeImage(product.image))}" alt="${escapeHTML(product.name)}">
      <div class="cart-item-info"><strong>${escapeHTML(product.name)}</strong><small>${formatPrice(product.price)} c/u</small>
        <div class="quantity-control"><button data-quantity="${escapeHTML(product.id)}" data-delta="-1" type="button" aria-label="Reducir cantidad">−</button><span>${item.quantity}</span><button data-quantity="${escapeHTML(product.id)}" data-delta="1" type="button" aria-label="Aumentar cantidad">+</button></div>
      </div><div class="cart-item-price">${formatPrice(product.price * item.quantity)}<button class="remove-item" data-remove="${escapeHTML(product.id)}" type="button">Quitar</button></div>
    </article>`;
  }).join("");
  $("#cart-items").innerHTML = items;
  $("#cart-empty").classList.toggle("hidden", cart.length > 0);
  $("#cart-summary").classList.toggle("hidden", cart.length === 0);
  const total = cart.reduce((sum, item) => sum + (products.find(product => product.id === item.id)?.price || 0) * item.quantity, 0);
  $("#cart-total").textContent = formatPrice(total);
  updateCartBadge();
}

function addToCart(productId) {
  const product = products.find(item => item.id === productId);
  if (!product?.stock) return;
  const existing = cart.find(item => item.id === productId);
  if (existing) existing.quantity += 1;
  else cart.push({ id: productId, quantity: 1 });
  Store.saveCart(cart);
  closeModal();
  renderCart();
  notify(`${product.name} agregado al carrito`);
}

function openCart() {
  closeModal(true);
  renderCart();
  trackOverlayInHistory();
  cartDrawer.classList.remove("hidden");
  modalBackdrop.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  $("#cart-button").setAttribute("aria-expanded", "true");
}

function closeDrawer(restoreOverflow = true, preserveHistory = false) {
  cartDrawer.classList.add("hidden");
  $("#cart-button").setAttribute("aria-expanded", "false");
  if (restoreOverflow && !activeModal) {
    modalBackdrop.classList.add("hidden");
    document.body.style.overflow = "";
  }
  if (!preserveHistory) releaseOverlayHistory();
}

function renderCustomerAuth(mode, name = "", contact = "") {
  const registering = mode === "register";
  authModal.innerHTML = `
    <button class="modal-close" data-close type="button" aria-label="Cerrar">×</button>
    <div class="modal-identity"><img src="assets/cuban-fashioner-logo.png" alt=""><span>Cuban Fashioner</span></div>
    <div class="eyebrow"><span class="eyebrow-line"></span> BIENVENIDO</div>
    <h2 class="auth-heading" id="auth-title">${registering ? "Crear cuenta de cliente" : "Inicia sesión"}</h2>
    <p class="auth-copy">${registering ? "Crea tu cuenta con correo o teléfono y una contraseña para continuar." : "Introduce el correo o teléfono y la contraseña de tu cuenta."}</p>
    <div class="auth-mode-switch" aria-label="Tipo de acceso">
      <button class="${registering ? "" : "active"}" data-auth-mode="login" type="button" aria-pressed="${!registering}">Iniciar sesión</button>
      <button class="${registering ? "active" : ""}" data-auth-mode="register" type="button" aria-pressed="${registering}">Crear cuenta</button>
    </div>
    <form class="auth-form" id="customer-form">
      ${registering ? `<label for="customer-name">Nombre completo</label><input id="customer-name" required maxlength="80" autocomplete="name" placeholder="Tu nombre" value="${escapeHTML(name)}">` : ""}
      <label for="customer-contact">Correo electrónico o teléfono</label><input id="customer-contact" required maxlength="120" autocomplete="username" placeholder="nombre@gmail.com o +53..." value="${escapeHTML(contact)}">
      <label for="customer-password">Contraseña</label><input id="customer-password" type="password" required minlength="8" maxlength="128" autocomplete="${registering ? "new-password" : "current-password"}" placeholder="${registering ? "Mínimo 8 caracteres" : "Tu contraseña"}">
      <button class="button button-primary" type="submit">${registering ? "Crear cuenta" : "Entrar"} <span>→</span></button>
    </form>
    <div class="auth-divider">o</div>
    <button class="button admin-access" id="admin-login-button" type="button">♛ Acceso de administrador</button>
    <p class="auth-hint">Acceso de demostración: <strong>${ADMIN_EMAIL}</strong> · contraseña <strong>${ADMIN_PASSWORD}</strong></p>`;
}

function showAuth() {
  const name = customer?.role === "customer" ? customer.name : "";
  const contact = customer?.role === "customer" ? customer.contact : "";
  renderCustomerAuth("login", name, contact);
  openDialog(authModal);
}

function showOrderConfirmation(order) {
  const message = [
    "Hola, quiero confirmar este pedido de Cuban Fashioner:",
    `Pedido: ${order.id}`,
    `Cliente: ${order.customer.name}`,
    `Contacto: ${order.customer.contact}`,
    "Productos:",
    ...order.products.map(item => `- ${item.name}: ${item.description} — ${item.quantity} x ${formatPrice(item.unitPrice)} = ${formatPrice(item.lineTotal)}`),
    `Total: ${formatPrice(order.total)} USD`,
    "Quedo pendiente para coordinar la recogida."
  ].join("\n");
  const whatsappUrl = `https://wa.me/5350727220?text=${encodeURIComponent(message)}`;
  orderModal.innerHTML = `
    <button class="modal-close" data-close type="button" aria-label="Cerrar">×</button>
    <div class="modal-identity"><img src="assets/cuban-fashioner-logo.png" alt=""><span>Cuban Fashioner</span></div>
    <div class="eyebrow"><span class="eyebrow-line"></span> PEDIDO REGISTRADO</div>
    <h2 id="order-title">¡Gracias por tu pedido!</h2>
    <p>Envía el resumen por WhatsApp para confirmar tu pedido y coordinar la recogida.</p>
    <div class="order-summary">
      <p class="order-number">Pedido <strong>${escapeHTML(order.id)}</strong></p>
      <ul class="order-products">${order.products.map(item => `
        <li><div><strong>${escapeHTML(item.name)}</strong><p>${escapeHTML(item.description)}</p><small>${item.quantity} × ${formatPrice(item.unitPrice)}</small></div><strong>${formatPrice(item.lineTotal)}</strong></li>`).join("")}</ul>
      <div class="order-total"><span>Total</span><strong>${formatPrice(order.total)} USD</strong></div>
    </div>
    <div class="order-actions"><a class="button button-primary whatsapp-order" href="${whatsappUrl}" target="_blank" rel="noopener noreferrer">Enviar por WhatsApp <span>↗</span></a><button class="button button-outline" id="copy-order" type="button">Copiar resumen</button></div>`;
  openDialog(orderModal);
  $("#copy-order").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(message);
      notify("Resumen del pedido copiado");
    } catch (error) {
      console.error("No se pudo copiar el resumen del pedido.", error);
      notify("No se pudo copiar el resumen. Inténtalo de nuevo.");
    }
  });
}

function confirmOrder() {
  if (!cart.length) return;
  if (!customer || customer.role !== "customer") {
    closeDrawer(false, true);
    showAuth();
    notify("Inicia sesión para confirmar el pedido");
    return;
  }
  const order = {
    id: `CF-${Date.now()}`,
    date: new Date().toISOString(),
    customer: { name: customer.name, contact: customer.contact },
    products: cart.map(item => {
      const product = products.find(entry => entry.id === item.id);
      const unitPrice = Number(product.price);
      return {
        name: product.name,
        description: product.specs,
        quantity: item.quantity,
        unitPrice,
        lineTotal: Number((unitPrice * item.quantity).toFixed(2))
      };
    }),
    total: Number(cart.reduce((sum, item) => sum + products.find(entry => entry.id === item.id).price * item.quantity, 0).toFixed(2))
  };
  const orders = Store.getOrders();
  orders.unshift(order);
  Store.saveOrders(orders);
  cart = [];
  Store.saveCart(cart);
  renderCart();
  closeDrawer(false, true);
  showOrderConfirmation(order);
}

function renderAdmin() {
  $("#admin-product-count").textContent = String(products.length);
  $("#inventory-count").textContent = `${products.length} ${products.length === 1 ? "producto" : "productos"}`;
  $("#admin-product-list").innerHTML = products.length ? products.map(product => `
    <article class="admin-product-row">
      <img src="${escapeHTML(safeImage(product.image))}" alt="">
      <div class="admin-product-text"><strong>${escapeHTML(product.name)}</strong><small>${formatPrice(product.price)} · <span class="admin-stock ${product.stock ? "available" : "unavailable"}">${product.stock ? "En stock" : "Agotado"}</span></small></div>
      <div class="admin-row-actions"><button data-edit="${escapeHTML(product.id)}" type="button">Editar</button><button data-stock="${escapeHTML(product.id)}" type="button">${product.stock ? "Agotar" : "Activar"}</button><button class="delete-product" data-delete="${escapeHTML(product.id)}" type="button" aria-label="Eliminar ${escapeHTML(product.name)}">×</button></div>
    </article>`).join("") : '<div class="admin-empty">Aún no hay productos. Agrega el primero con el formulario.</div>';
  $("#admin-product-list").querySelectorAll("img").forEach(image => image.addEventListener("error", () => { image.src = FALLBACK_IMAGE; }, { once: true }));
  const orders = Store.getOrders();
  $("#orders-count").textContent = `${orders.length} ${orders.length === 1 ? "pedido" : "pedidos"}`;
  $("#admin-orders").innerHTML = orders.length ? orders.map(order => `
    <article class="order-row"><div class="order-row-top"><div><strong>${escapeHTML(order.customer.name)}</strong><br><small>${escapeHTML(order.customer.contact)} · ${new Date(order.date).toLocaleString("es-ES")}</small></div><strong>${formatPrice(order.total)}</strong></div><p>${order.products.map(item => `${escapeHTML(item.name)} × ${item.quantity}`).join(" · ")}</p></article>`).join("") : '<div class="admin-empty">Los pedidos confirmados aparecerán aquí.</div>';
}

function resetProductForm() {
  $("#product-form").reset();
  $("#product-id").value = "";
  $("#product-stock").checked = true;
  $("#form-title").textContent = "Agregar producto";
  $("#save-product").innerHTML = 'Agregar al catálogo <span>＋</span>';
  $("#cancel-edit").classList.add("hidden");
}

function beginEdit(productId) {
  const product = products.find(item => item.id === productId);
  if (!product) return;
  $("#product-id").value = product.id;
  $("#product-name").value = product.name;
  $("#product-brand").value = product.brand;
  $("#product-image").value = product.image || "";
  $("#product-specs").value = product.specs;
  $("#product-price").value = product.price;
  $("#product-stock").checked = product.stock;
  $("#form-title").textContent = "Editar producto";
  $("#save-product").innerHTML = 'Guardar cambios <span>✓</span>';
  $("#cancel-edit").classList.remove("hidden");
  $("#product-name").focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

$("#search-input").addEventListener("input", renderProducts);
$("#availability-filter").addEventListener("change", renderProducts);
$("#clear-search").addEventListener("click", () => {
  $("#search-input").value = "";
  $("#availability-filter").value = "all";
  renderProducts();
});
productGrid.addEventListener("click", event => {
  const brandCard = event.target.closest("[data-brand]");
  if (brandCard) showBrandModels(brandCard.dataset.brand);
});
brandModal.addEventListener("click", event => {
  const productCard = event.target.closest("[data-product-id]");
  if (productCard) showProduct(productCard.dataset.productId);
});
document.querySelectorAll("[data-theme-toggle]").forEach(button => button.addEventListener("click", () => {
  const nextTheme = document.body.classList.contains("dark-mode") ? "light" : "dark";
  applyTheme(nextTheme);
  try {
    Store.saveTheme(nextTheme);
  } catch (error) {
    console.error("No se pudo guardar la preferencia de tema.", error);
    notify(error.message || "No se pudo guardar el modo de color.");
  }
}));
$("#account-button").addEventListener("click", () => {
  if (customer?.role === "admin") setPageMode(true);
  else if (customer?.role === "customer") {
    customer = null;
    Store.clearCustomer();
    renderProducts();
    notify("Has cerrado sesión");
  } else showAuth();
});
$("#cart-button").addEventListener("click", openCart);
$("#checkout-button").addEventListener("click", confirmOrder);
modalBackdrop.addEventListener("click", () => {
  closeModal();
  closeDrawer();
});
document.addEventListener("click", event => {
  const closeButton = event.target.closest("[data-close]");
  if (closeButton) {
    closeModal();
    closeDrawer();
    return;
  }
  const addButton = event.target.closest("[data-add]");
  if (addButton) {
    addToCart(addButton.dataset.add);
    return;
  }
  const quantityButton = event.target.closest("[data-quantity]");
  if (quantityButton) {
    const item = cart.find(entry => entry.id === quantityButton.dataset.quantity);
    if (!item) return;
    item.quantity += Number(quantityButton.dataset.delta);
    if (item.quantity <= 0) cart = cart.filter(entry => entry.id !== item.id);
    Store.saveCart(cart);
    renderCart();
    return;
  }
  const removeButton = event.target.closest("[data-remove]");
  if (removeButton) {
    cart = cart.filter(item => item.id !== removeButton.dataset.remove);
    Store.saveCart(cart);
    renderCart();
  }
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    closeModal();
    closeDrawer();
  }
});
window.addEventListener("popstate", () => {
  const historyState = window.history.state;
  if (historyState?.cubanFashionerOverlay && historyState.cubanFashionerBrandKey) {
    overlayHistoryActive = true;
    showBrandModels(historyState.cubanFashionerBrandKey);
    return;
  }
  if (!overlayHistoryActive) return;
  overlayHistoryActive = false;
  if (activeModal) closeModal(true);
  else if (!cartDrawer.classList.contains("hidden")) closeDrawer(true, true);
});

authModal.addEventListener("submit", async event => {
  if (event.target.id !== "customer-form") return;
  event.preventDefault();
  const form = event.target;
  const registering = Boolean(form.querySelector("#customer-name"));
  const name = registering ? $("#customer-name").value.trim() : "";
  const contact = $("#customer-contact").value.trim();
  const normalizedContact = contact.toLocaleLowerCase();
  const password = $("#customer-password").value;
  const submitButton = form.querySelector('[type="submit"]');
  submitButton.disabled = true;
  try {
    const customers = Store.getCustomers();
    const existing = customers.find(account => account.contact.toLocaleLowerCase() === normalizedContact);
    let account;
    if (registering) {
      if (!name) {
        notify("Escribe tu nombre completo");
        return;
      }
      if (existing) {
        notify("Ya existe una cuenta con ese correo o teléfono. Inicia sesión.");
        renderCustomerAuth("login", "", contact);
        return;
      }
      const salt = createPasswordSalt();
      const passwordHash = await hashPassword(password, salt);
      account = { name, contact, salt, passwordHash };
      Store.saveCustomers([...customers, account]);
    } else {
      if (!existing) {
        notify("No existe una cuenta con ese correo o teléfono. Crea una cuenta primero.");
        return;
      }
      const passwordHash = await hashPassword(password, existing.salt);
      if (passwordHash !== existing.passwordHash) {
        notify("Contraseña incorrecta");
        $("#customer-password").value = "";
        $("#customer-password").focus();
        return;
      }
      account = existing;
    }
    customer = { name: account.name, contact: account.contact, role: "customer" };
    Store.saveCustomer(customer);
    closeModal();
    renderProducts();
    notify(`Bienvenido/a, ${account.name.split(" ")[0]}`);
  } catch (error) {
    console.error("No se pudo autenticar la cuenta de cliente.", error);
    notify(error.message || "No se pudo completar el acceso. Inténtalo de nuevo.");
  } finally {
    if (submitButton.isConnected) submitButton.disabled = false;
  }
});
authModal.addEventListener("click", event => {
  const modeButton = event.target.closest("[data-auth-mode]");
  if (modeButton) {
    renderCustomerAuth(modeButton.dataset.authMode, $("#customer-name")?.value || "", $("#customer-contact").value);
    return;
  }
  if (event.target.id === "admin-login-button") {
    authModal.innerHTML = `
      <button class="modal-close" data-close type="button" aria-label="Cerrar">×</button>
      <div class="modal-identity"><img src="assets/cuban-fashioner-logo.png" alt=""><span>Cuban Fashioner</span></div>
      <div class="eyebrow"><span class="eyebrow-line"></span> ACCESO RESTRINGIDO</div>
      <h2 class="auth-heading" id="auth-title">Administración</h2><p class="auth-copy">Introduce las credenciales de administrador.</p>
      <form class="auth-form" id="admin-form"><label for="admin-email">Correo</label><input id="admin-email" type="email" autocomplete="username" required value="${ADMIN_EMAIL}"><label for="admin-password">Contraseña</label><input id="admin-password" type="password" autocomplete="current-password" required><button class="button button-primary" type="submit">Entrar al panel <span>→</span></button></form>
      <p class="auth-hint">Credenciales de demostración disponibles en la documentación del proyecto.</p>`;
    $("#admin-password").focus();
  }
});
authModal.addEventListener("submit", event => {
  if (event.target.id !== "admin-form") return;
  event.preventDefault();
  if ($("#admin-email").value.trim().toLowerCase() !== ADMIN_EMAIL || $("#admin-password").value !== ADMIN_PASSWORD) {
    notify("Correo o contraseña incorrectos");
    $("#admin-password").value = "";
    $("#admin-password").focus();
    return;
  }
  customer = { name: "Administrador", contact: ADMIN_EMAIL, role: "admin" };
  Store.saveCustomer(customer);
  closeModal();
  setPageMode(true);
});

$("#product-form").addEventListener("submit", event => {
  event.preventDefault();
  const id = $("#product-id").value;
  const product = {
    id: id || `product-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: $("#product-name").value.trim(),
    brand: $("#product-brand").value.trim(),
    image: $("#product-image").value.trim() || FALLBACK_IMAGE,
    specs: $("#product-specs").value.trim(),
    price: Number($("#product-price").value),
    stock: $("#product-stock").checked
  };
  if (!product.name || !product.brand || !product.specs || !Number.isFinite(product.price) || product.price <= 0) {
    notify("Completa los campos requeridos con datos válidos");
    return;
  }
  try {
    if (id) products = products.map(item => item.id === id ? product : item);
    else products = [product, ...products];
    persistProducts();
    resetProductForm();
    renderAdmin();
    renderProducts();
    notify(id ? "Producto actualizado" : "Producto agregado al catálogo");
  } catch (error) {
    notify(error.message);
  }
});
$("#cancel-edit").addEventListener("click", resetProductForm);
$("#admin-product-list").addEventListener("click", event => {
  const editButton = event.target.closest("[data-edit]");
  if (editButton) {
    beginEdit(editButton.dataset.edit);
    return;
  }
  const stockButton = event.target.closest("[data-stock]");
  if (stockButton) {
    products = products.map(product => product.id === stockButton.dataset.stock ? { ...product, stock: !product.stock } : product);
    persistProducts();
    renderAdmin();
    renderProducts();
    notify("Disponibilidad actualizada");
    return;
  }
  const deleteButton = event.target.closest("[data-delete]");
  if (deleteButton && window.confirm("¿Eliminar este producto del catálogo?")) {
    products = products.filter(product => product.id !== deleteButton.dataset.delete);
    cart = cart.filter(item => item.id !== deleteButton.dataset.delete);
    try {
      persistProducts();
      Store.saveCart(cart);
      renderAdmin();
      renderProducts();
      notify("Producto eliminado");
    } catch (error) {
      notify(error.message);
    }
  }
});
$("#back-to-store").addEventListener("click", () => setPageMode(false));
$("#admin-logout").addEventListener("click", () => {
  customer = null;
  Store.clearCustomer();
  setPageMode(false);
  notify("Has cerrado sesión");
});

$("#current-year").textContent = String(new Date().getFullYear());
applyTheme(Store.getTheme());
renderProducts();
if (customer?.role === "admin") setPageMode(true);
