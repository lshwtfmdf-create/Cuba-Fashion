# Cuban Fashioner

Tienda de demostración para catálogo de baterías de laptop, carrito y recogida local en Cuba. Está implementada con HTML, CSS y JavaScript nativo, sin dependencias ni servidor.

## Cómo ejecutar

Abre `index.html` en un navegador moderno. Si el navegador bloquea módulos JavaScript al abrir archivos locales, inicia un servidor estático desde la carpeta del proyecto, por ejemplo:

```sh
python -m http.server 8000
```

Después abre `http://localhost:8000`.

## Funciones incluidas

- Catálogo adaptable con búsqueda por modelo, marca o especificaciones y filtro de disponibilidad.
- Detalle de producto en modal y carrito con cantidades, subtotales y total.
- Registro e inicio de sesión de clientes con contraseña y correo/teléfono.
- Catálogo con secciones de marca que abren un modal con sus modelos; conserva búsqueda y filtro de disponibilidad.
- Modo oscuro/claro con preferencia guardada localmente.
- Botón Atrás del navegador o del teléfono para cerrar el diálogo o carrito abierto sin salir de la tienda.
- Logotipo de Cuban Fashioner en la navegación, el pie de página, el carrito, la administración, los diálogos y como icono del sitio.
- Confirmación de pedido con productos, descripciones, precios por unidad, subtotales y total; opción de copiar el resumen legible o abrir WhatsApp con el mensaje preparado para `+53 50727220`, e historial local visible para el administrador.
- Panel con alta, edición, eliminación y actualización de disponibilidad del inventario.
- Persistencia local del catálogo, cuentas de demostración, sesión, carrito y pedidos con `localStorage`. Las contraseñas de cliente se guardan como hashes PBKDF2 con sal.

## Acceso de demostración

- **Administrador:** `admin@cuban-fashioner.com`
- **Contraseña:** `Cuba2026!`

La autenticación no es segura para producción: las cuentas y los datos se procesan en el navegador. `localStorage` es local al dispositivo y no sincroniza con otros usuarios. Para un lanzamiento real, sustituye esta simulación por un backend con autenticación, base de datos, autorización y procesamiento de pedidos seguros.
